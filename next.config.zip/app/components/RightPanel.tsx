import styles from './RightPanel.module.css'

export default function RightPanel() {
  return (
    <aside className={styles.rightPanel}>
      <h3>Right Panel</h3>
      <p>Additional information or widgets can go here.</p>
    </aside>
  )
}

