import ResponsivePage from './components/ResponsivePage'

export default function Home() {
  return <ResponsivePage />
}